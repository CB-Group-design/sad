# CB Design

A one-page marketing site for CB Design — a small web design studio based in Essex, founded by William and Thomas.

## What's in here

```
index.html      the whole site (structure + content)
styles.css       all styling
script.js        scroll reveals, nav behaviour, and the Three.js 3D orb scenes
favicon.svg      the little orb mark used as the browser tab icon
```

It's a static site with no build step — just plain HTML, CSS and JS. The only external dependency is loaded from a CDN at runtime:

- Google Fonts (Sora, Inter, IBM Plex Mono)
- [Three.js](https://threejs.org/) r128, used for the floating 3D sphere animations in the hero, about, and pricing sections

Both load over the internet when someone visits the page, so an internet connection is required for fonts and the 3D effects to appear (the rest of the site works fine without it).

## Editing the content

Everything text-based — pricing, copy, the founders' names, the email address — lives directly in `index.html`. Search for the bit you want to change and edit it directly; there's no templating system.

A few common things you might want to update:

- **Email address** — search for `cb.congroup@gmail.com` in `index.html` (it appears a few times, in `mailto:` links and in the footer/contact section).
- **Price** — search for `£999.99` and `£1,400` in `index.html`.
- **Colours / fonts** — the CSS custom properties at the top of `styles.css` (the `:root { ... }` block) control the whole colour palette in one place.

## Running it locally

You can just open `index.html` directly in a browser. For the smoothest experience (some browsers restrict certain features when opening files directly), you can also serve it locally:

```bash
# from inside this folder
python3 -m http.server 8000
# then open http://localhost:8000 in your browser
```

## Deploying with GitHub Pages

1. Create a new GitHub repository and push these files to it (e.g. as the `main` branch).
2. In the repo, go to **Settings → Pages**.
3. Under "Build and deployment", set **Source** to "Deploy from a branch", choose the `main` branch and the `/ (root)` folder, then save.
4. GitHub will give you a URL (usually `https://<your-username>.github.io/<repo-name>/`) — it can take a minute or two to go live after the first push.

That's it — no build tools, no `npm install`, nothing else to configure.
