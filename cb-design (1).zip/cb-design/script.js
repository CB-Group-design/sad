// Nav background on scroll
  const nav = document.getElementById('nav');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 10);
  }, { passive: true });

  // Scrollspy for nav links
  const navAnchors = ['home','work','about','process','pricing','contact'];
  const navLinkMap = {};
  navAnchors.forEach(id => { navLinkMap[id] = document.querySelector(`.nav-links a[href="#${id}"]`); });
  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        Object.values(navLinkMap).forEach((a) => a && a.classList.remove('active'));
        const link = navLinkMap[entry.target.id];
        if (link) link.classList.add('active');
      }
    });
  }, { threshold: 0.4, rootMargin: '-30% 0px -40% 0px' });
  navAnchors.forEach((id) => {
    const el = document.getElementById(id);
    if (el) spyObserver.observe(el);
  });

  // Reveal-on-scroll
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.18 });
  document.querySelectorAll('.reveal').forEach((el) => revealObserver.observe(el));

  // Hero cursor glow
  const heroSection = document.querySelector('.hero');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (heroSection && !reduceMotion && window.matchMedia('(hover: hover)').matches) {
    heroSection.addEventListener('mousemove', (e) => {
      const rect = heroSection.getBoundingClientRect();
      heroSection.style.setProperty('--mx', ((e.clientX - rect.left) / rect.width) * 100 + '%');
      heroSection.style.setProperty('--my', ((e.clientY - rect.top) / rect.height) * 100 + '%');
    });
  }

  // Tilt effect on work cards
  if (!reduceMotion && window.matchMedia('(hover: hover)').matches) {
    document.querySelectorAll('.work-card').forEach((card) => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        card.style.transform = `perspective(800px) rotateY(${px * 10}deg) rotateX(${-py * 10}deg) scale(1.02)`;
      });
      card.addEventListener('mouseleave', () => { card.style.transform = ''; });
    });
  }

  // Shared helper: a scroll-driven group of glossy 3D spheres inside a given canvas/section
  function initOrbScene(canvasId, sectionEl, sphereDefs, opts) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !sectionEl || typeof THREE === 'undefined') return;
    if (window.innerWidth < 900) return; // keep mobile light

    const o = opts || {};
    let width = canvas.clientWidth, height = canvas.clientHeight;
    if (!width || !height) return;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height, false);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0, o.cameraZ || 9);

    const key = new THREE.PointLight(o.keyColor || 0xFF8C42, 3.2, 60);
    key.position.set(4, 4, 5);
    const fill = new THREE.PointLight(o.fillColor || 0x3D6FB5, 1.3, 60);
    fill.position.set(-5, -2, 3);
    const amb = new THREE.AmbientLight(0x1a1a1a, 1.2);
    scene.add(key, fill, amb);

    const group = new THREE.Group();
    scene.add(group);

    const meshes = sphereDefs.map((def) => {
      const geo = new THREE.SphereGeometry(def.r, 48, 48);
      const mat = new THREE.MeshStandardMaterial({ color: def.color, metalness: 0.55, roughness: 0.32 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(def.start);
      group.add(mesh);
      return { mesh, start: def.start, end: def.end, speed: 0.08 + Math.random() * 0.08 };
    });

    let targetProgress = 0, progress = 0;
    function updateProgress() {
      const rect = sectionEl.getBoundingClientRect();
      const total = sectionEl.offsetHeight || 1;
      const passed = Math.min(Math.max(-rect.top, 0), total);
      targetProgress = passed / total;
    }
    window.addEventListener('scroll', updateProgress, { passive: true });
    updateProgress();

    function resize() {
      width = canvas.clientWidth; height = canvas.clientHeight;
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    }
    window.addEventListener('resize', resize);

    let running = true;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { running = e.isIntersecting; });
    }, { threshold: 0.05 });
    io.observe(sectionEl);

    const clock = new THREE.Clock();
    function animate() {
      requestAnimationFrame(animate);
      if (!running) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      progress += (targetProgress - progress) * 0.07;
      meshes.forEach((m) => {
        m.mesh.position.lerpVectors(m.start, m.end, progress);
        if (!reduceMotion) {
          m.mesh.rotation.x += dt * m.speed;
          m.mesh.rotation.y += dt * m.speed * 1.4;
        }
      });
      group.rotation.y = progress * (o.spin || 0.35);
      renderer.render(scene, camera);
    }
    animate();
  }

  // Hero: a warm key sphere drifting in from the top-right, a cool sphere receding behind it
  initOrbScene('hero-canvas', document.querySelector('.hero'), [
    { r: 1.7, color: 0x3a1a10, start: new THREE.Vector3(3.2, 1.6, -1), end: new THREE.Vector3(3.0, 0.4, 0) },
    { r: 0.95, color: 0x0c2326, start: new THREE.Vector3(-3.6, 2.6, -2.5), end: new THREE.Vector3(-3.2, 1.4, -1.5) },
  ], { cameraZ: 9, spin: 0.3, keyColor: 0xFF8C42, fillColor: 0x3D6FB5 });

  // About: a single cool-warm sphere drifting behind the founder cards
  initOrbScene('about-canvas', document.querySelector('.about'), [
    { r: 1.3, color: 0x18222a, start: new THREE.Vector3(1.2, 1.4, -1), end: new THREE.Vector3(0.6, -0.6, 0) },
  ], { cameraZ: 8, spin: 0.2, keyColor: 0x6FB7FF, fillColor: 0xFF6B35 });

  // Pricing: a single warm sphere drifting behind the price card heading
  initOrbScene('price-canvas', document.querySelector('.pricing'), [
    { r: 1.1, color: 0x3a1a10, start: new THREE.Vector3(-2.6, 1.6, -1), end: new THREE.Vector3(-2.2, 0.6, 0) },
  ], { cameraZ: 8, spin: 0.25, keyColor: 0xFF8C42, fillColor: 0x3D6FB5 });
